

<?php $__env->startSection('title', 'Add Quotation Country - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="error"><?php echo e($errors->first()); ?></div>
  <?php endif; ?>

  <div style="display:flex; gap:8px; align-items:center; margin-bottom:12px">
    <a class="btn" href="<?php echo e(route('admin.quotationcountries.index')); ?>">Back</a>
    <h2 style="margin:0">Add Quotation Country</h2>
  </div>

  <form method="POST" action="<?php echo e(route('admin.quotationcountries.store')); ?>">
    <?php echo csrf_field(); ?>
    <label for="name">Country name</label>
    <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required placeholder="United States">

    <label for="code">Code (optional)</label>
    <input id="code" type="text" name="code" value="<?php echo e(old('code')); ?>" placeholder="US">

    <label for="rate_per_kg">Rate per kg</label>
    <input id="rate_per_kg" type="number" step="0.01" min="0" name="rate_per_kg" value="<?php echo e(old('rate_per_kg', '0')); ?>" required>

    <label for="base_fee">Base fee (optional)</label>
    <input id="base_fee" type="number" step="0.01" min="0" name="base_fee" value="<?php echo e(old('base_fee', '0')); ?>">

    <label for="sort_order">Sort order</label>
    <input id="sort_order" type="number" min="0" name="sort_order" value="<?php echo e(old('sort_order', 0)); ?>">

    <div class="actions" style="margin-top:12px; display:flex; gap:8px">
      <button class="btn" type="submit">Create</button>
      <a class="btn" href="<?php echo e(route('admin.quotationcountries.index')); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/quotationcountries/create.blade.php ENDPATH**/ ?>