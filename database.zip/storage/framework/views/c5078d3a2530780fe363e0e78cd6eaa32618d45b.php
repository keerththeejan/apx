

<?php $__env->startSection('title', 'Customer Reviews - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Customer Reviews</h2>
    </div>
    <div>
      <a class="btn" href="<?php echo e(route('admin.customerreviews.create')); ?>">Add Review</a>
    </div>
  </div>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Customer</th>
          <th>Role / Company</th>
          <th>Review</th>
          <th>Rating</th>
          <th>Visible</th>
          <th>Order</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($r->id); ?></td>
            <td><?php echo e($r->customer_name); ?></td>
            <td><?php echo e($r->role_or_company ?? '—'); ?></td>
            <td style="max-width:320px"><?php echo e(\Illuminate\Support\Str::limit($r->review_text, 80)); ?></td>
            <td><?php echo e($r->rating ? str_repeat('★', (int)$r->rating) . str_repeat('☆', 5 - (int)$r->rating) : '—'); ?></td>
            <td>
              <?php if($r->is_visible): ?>
                <span style="background:#052; color:#c7f9cc; border:1px solid #0a4; padding:4px 8px; border-radius:8px">Visible</span>
              <?php else: ?>
                <span style="background: rgba(239,68,68,.15); color:#fecaca; border:1px solid rgba(239,68,68,.35); padding:4px 8px; border-radius:8px">Hidden</span>
              <?php endif; ?>
            </td>
            <td><?php echo e($r->sort_order); ?></td>
            <td class="actions" style="display:flex; gap:8px; flex-wrap:wrap">
              <a class="btn" href="<?php echo e(route('admin.customerreviews.edit', $r)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.customerreviews.destroy', $r)); ?>" onsubmit="return confirm('Delete this review?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn danger" type="submit">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="8" style="color:#94a3b8">No customer reviews yet. Click "Add Review".</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if(method_exists($reviews ?? null, 'links')): ?>
    <div style="margin-top:10px"><?php echo $reviews->withQueryString()->links(); ?></div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/customerreviews/index.blade.php ENDPATH**/ ?>