<header class="topbar" style="<?php echo e(!empty($cfgHeaderBg) ? '--header-bg: '.$cfgHeaderBg.';' : ''); ?><?php echo e(!empty($cfgHeaderBorder) ? '--header-border: '.$cfgHeaderBorder.';' : ''); ?><?php echo e(!empty($cfgHeaderLink) ? '--header-link: '.$cfgHeaderLink.';' : ''); ?><?php echo e(!empty($cfgHeaderText) ? '--header-text: '.$cfgHeaderText.';' : ''); ?><?php echo e(!empty($cfgHeaderTagline) ? '--header-tagline: '.$cfgHeaderTagline.';' : ''); ?><?php echo e(!empty($cfgBrandSize) ? '--brand-size: '.(int)$cfgBrandSize.'px;' : ''); ?><?php echo e(!empty($cfgTaglineSize) ? '--tagline-size: '.(int)$cfgTaglineSize.'px;' : ''); ?><?php echo e(isset($cfgMenuFontSize) && $cfgMenuFontSize !== '' ? '--menu-size: '.(int)$cfgMenuFontSize.'px;' : ''); ?><?php echo e(!empty($cfgBrandWeight) ? '--brand-weight: '.$cfgBrandWeight.';' : ''); ?><?php echo e(!empty($cfgBrandStyle) ? '--brand-style: '.$cfgBrandStyle.';' : ''); ?>">
  <div class="nav">
    <div class="header-left">
      <div class="brand">
        <?php if(!empty($logoSrc)): ?>
          <img src="<?php echo e($logoSrc); ?>" alt="Logo">
        <?php else: ?>
          <span>📦</span>
        <?php endif; ?>
        <span><?php echo e($cfgName ?? 'apx.lk'); ?></span>
      </div>
      <?php if(trim((string)($cfgTag ?? '')) !== ''): ?>
        <span class="header-tagline"><?php echo e($cfgTag); ?></span>
      <?php endif; ?>
      <div class="header-menu">
        <?php $localeM = app()->getLocale(); $langLabelM = $localeM === 'en' ? 'EN' : ($localeM === 'ta' ? 'தமிழ்' : 'සිංහල'); ?>
        <div class="lang-switcher-mobile lang-in-header-mobile" aria-label="<?php echo e(__('site.language')); ?>">
          <div class="lang-dropdown" tabindex="-1">
            <button type="button" class="lang-dropdown-trigger" aria-expanded="false" aria-haspopup="true" aria-label="<?php echo e(__('site.language')); ?>">
              <span class="lang-globe" aria-hidden="true">🌐</span>
              <span class="lang-current"><?php echo e($langLabelM); ?></span>
            </button>
            <div class="lang-dropdown-menu" role="menu">
              <a href="<?php echo e(route('locale.switch', ['locale' => 'en'])); ?>" role="menuitem" class="<?php echo e($localeM === 'en' ? 'active' : ''); ?>">EN</a>
              <a href="<?php echo e(route('locale.switch', ['locale' => 'ta'])); ?>" role="menuitem" class="<?php echo e($localeM === 'ta' ? 'active' : ''); ?>">தமிழ்</a>
              <a href="<?php echo e(route('locale.switch', ['locale' => 'si'])); ?>" role="menuitem" class="<?php echo e($localeM === 'si' ? 'active' : ''); ?>">සිංහල</a>
            </div>
          </div>
        </div>
        <button id="theme-toggle" class="themebtn themebtn-icon" type="button" aria-label="Toggle theme"><span class="theme-icon" aria-hidden="true"></span></button>
        <button class="hamb" type="button" aria-expanded="false" aria-controls="primary-links"><?php echo e(__('site.menu')); ?></button>
        <div id="primary-links" class="links">
          <?php $homePath = trim((string) parse_url(url('/'), PHP_URL_PATH), '/'); ?>
          <?php if(isset($navLinks) && $navLinks->count()): ?>
            <?php $__currentLoopData = $navLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $linkUrl = $nl->url ?? '';
                if (!empty($linkUrl)) {
                  $linkUrl = trim((string) $linkUrl);
                  if (!\Illuminate\Support\Str::startsWith($linkUrl, ['http://', 'https://', 'mailto:', 'tel:', '#'])) {
                    $linkUrl = url($linkUrl);
                  }
                }
                $path = $linkUrl ? trim((string) parse_url($linkUrl, PHP_URL_PATH), '/') : '';
                $isHomeUrl = ($path === $homePath || $path === 'home');
              ?>
              <?php if($isHomeUrl): ?> <?php continue; ?> <?php endif; ?>
              <a href="<?php echo e($linkUrl); ?>" <?php if($nl->target ?? null): ?> target="<?php echo e($nl->target); ?>" rel="noopener" <?php endif; ?>>
                <?php if(!empty($nl->icon)): ?><span style="margin-right:6px"><?php echo e($nl->icon); ?></span><?php endif; ?><?php echo e($nl->label); ?>

              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <a href="<?php echo e(route('track')); ?>"><?php echo e(__('site.track')); ?></a>
          <?php endif; ?>
          <a href="<?php echo e(route('login')); ?>"><?php echo e(__('site.login')); ?></a>
        </div>
      </div>
    </div>
    <div class="header-right">
      <div class="header-tracking">
        <a href="<?php echo e(route('track')); ?>" class="header-track-btn" style="display:inline-block;text-decoration:none;line-height:1"><?php echo e(__('site.track')); ?></a>
      </div>
      <div class="header-contact">
        <?php if(!empty($headerContactPhone)): ?>
          <a href="tel:<?php echo e(preg_replace('/\s+/', '', $headerContactPhone)); ?>" class="header-contact-link" title="Call us">📞 <?php echo e($headerContactPhone); ?></a>
        <?php endif; ?>
        <?php if(!empty($headerContactEmail)): ?>
          <a href="mailto:<?php echo e($headerContactEmail); ?>" class="header-contact-link" title="Email us">✉️ <?php echo e($headerContactEmail); ?></a>
        <?php endif; ?>
      </div>
      <?php $locale = app()->getLocale(); $langLabel = $locale === 'en' ? 'EN' : ($locale === 'ta' ? 'தமிழ்' : 'සිංහල'); ?>
      <div class="lang-switcher" aria-label="<?php echo e(__('site.language')); ?>">
        <div class="lang-dropdown" tabindex="-1">
          <button type="button" class="lang-dropdown-trigger" aria-expanded="false" aria-haspopup="true" aria-label="<?php echo e(__('site.language')); ?>">
            <span class="lang-globe" aria-hidden="true">🌐</span>
            <span class="lang-current"><?php echo e($langLabel); ?></span>
          </button>
          <div class="lang-dropdown-menu" role="menu">
            <a href="<?php echo e(route('locale.switch', ['locale' => 'en'])); ?>" role="menuitem" class="<?php echo e($locale === 'en' ? 'active' : ''); ?>">EN</a>
            <a href="<?php echo e(route('locale.switch', ['locale' => 'ta'])); ?>" role="menuitem" class="<?php echo e($locale === 'ta' ? 'active' : ''); ?>">தமிழ்</a>
            <a href="<?php echo e(route('locale.switch', ['locale' => 'si'])); ?>" role="menuitem" class="<?php echo e($locale === 'si' ? 'active' : ''); ?>">සිංහල</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<?php /**PATH C:\wamp64\www\apx\resources\views/partials/header.blade.php ENDPATH**/ ?>