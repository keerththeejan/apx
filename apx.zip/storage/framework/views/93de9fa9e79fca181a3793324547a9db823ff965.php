

<?php $__env->startSection('title', 'Add Customer Review - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="error"><?php echo e($errors->first()); ?></div>
  <?php endif; ?>

  <div style="display:flex; gap:8px; align-items:center; margin-bottom:12px">
    <a class="btn" href="<?php echo e(route('admin.customerreviews.index')); ?>">Back</a>
    <h2 style="margin:0">Add Customer Review</h2>
  </div>

  <form method="POST" action="<?php echo e(route('admin.customerreviews.store')); ?>">
    <?php echo csrf_field(); ?>

    <label for="customer_name">Customer name</label>
    <input id="customer_name" type="text" name="customer_name" value="<?php echo e(old('customer_name')); ?>" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)" required>

    <label for="role_or_company">Role / Company (optional)</label>
    <input id="role_or_company" type="text" name="role_or_company" value="<?php echo e(old('role_or_company')); ?>" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)" placeholder="e.g. Logistics Manager">

    <label for="review_text">Review text</label>
    <textarea id="review_text" name="review_text" class="input" style="min-height:120px; padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)" required><?php echo e(old('review_text')); ?></textarea>

    <label for="rating">Rating (1–5 stars, optional)</label>
    <select id="rating" name="rating" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">
      <option value="">— No rating —</option>
      <?php for($i = 1; $i <= 5; $i++): ?>
        <option value="<?php echo e($i); ?>" <?php echo e(old('rating') == $i ? 'selected' : ''); ?>><?php echo e($i); ?> ★</option>
      <?php endfor; ?>
    </select>

    <label for="sort_order">Sort order</label>
    <input id="sort_order" type="number" min="0" name="sort_order" value="<?php echo e(old('sort_order', 0)); ?>" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">

    <label style="display:flex; align-items:center; gap:8px; margin-top:10px">
      <input type="checkbox" name="is_visible" value="1" <?php echo e(old('is_visible', true) ? 'checked' : ''); ?>>
      <span>Visible on site</span>
    </label>

    <div class="actions" style="margin-top:12px; display:flex; gap:8px">
      <button class="btn" type="submit">Save Review</button>
      <a class="btn" href="<?php echo e(route('admin.customerreviews.index')); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/customerreviews/create.blade.php ENDPATH**/ ?>