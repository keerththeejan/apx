<footer class="footer">
  <?php
    $aboutText = $cfgFooter ?? __('site.all_rights_reserved'); // legacy footer text
    $contactEmail = optional(\App\Models\Setting::where('key','contact_email')->first())->value;
    $contactPhone = optional(\App\Models\Setting::where('key','contact_phone')->first())->value;
    $contactAddr  = optional(\App\Models\Setting::where('key','address')->first())->value;
    $footerLogo = optional(\App\Models\Setting::where('key','footer_logo_url')->first())->value;
    $footerNews = optional(\App\Models\Setting::where('key','footer_newsletter')->first())->value;
    $footerHours = optional(\App\Models\Setting::where('key','footer_hours')->first())->value;
    $aboutTitle = optional(\App\Models\Setting::where('key','footer_about_title')->first())->value ?? 'About';
    $aboutBody  = optional(\App\Models\Setting::where('key','footer_about_text')->first())->value;
    $aboutLinkLabel = optional(\App\Models\Setting::where('key','footer_about_link_label')->first())->value;
    $aboutLinkUrl   = optional(\App\Models\Setting::where('key','footer_about_link_url')->first())->value;
    $showSocial = (bool) (optional(\App\Models\Setting::where('key','footer_show_social')->first())->value ?? true);
    $ftBg = optional(\App\Models\Setting::where('key','footer_bg_color')->first())->value ?? '#0b1220';
    $ftText = optional(\App\Models\Setting::where('key','footer_text_color')->first())->value ?? '#94a3b8';
    $ftLink = optional(\App\Models\Setting::where('key','footer_link_color')->first())->value ?? '#cbd5e1';
    $footerLinks = collect();
    if (\Illuminate\Support\Facades\Schema::hasTable('footer_links')) {
      $footerLinks = \App\Models\FooterLink::where('is_visible',true)->orderBy('sort_order')->orderBy('id')->get();
    }
    $social = collect();
    if (\Illuminate\Support\Facades\Schema::hasTable('social_links')) {
      $social = \App\Models\SocialLink::where('is_visible',true)->orderBy('sort_order')->orderBy('id')->get();
    }

    $footerBgEffective = $ftBg ?: ($cfgHeaderBg ?: '#0b1220');
    $footerTextEffective = $ftText ?: '#94a3b8';
    $footerLinkEffective = $ftLink ?: '#cbd5e1';
    $footerBorderEffective = $cfgHeaderBorder ?: 'rgba(148,163,184,.12)';
  ?>

  <div style="width:100%; margin:0; padding:0; background: <?php echo e($footerBgEffective); ?>; color: <?php echo e($footerTextEffective); ?>; border-top:1px solid <?php echo e($footerBorderEffective); ?>">
    <div class="footer-inner">
      <div class="footer-grid">
        <div class="footer-col">
          <?php if(!empty($footerLogo)): ?>
            <div class="footer-logo"><a href="<?php echo e(url('/')); ?>" style="display:inline-block; color:inherit; text-decoration:none"><img src="<?php echo e($toUrl($footerLogo)); ?>" alt="<?php echo e($cfgName ?? 'Logo'); ?>" style="border-color: rgba(255,255,255,.2)"></a></div>
          <?php elseif(!empty($cfgLogo)): ?>
            <div class="footer-logo"><a href="<?php echo e(url('/')); ?>" style="display:inline-block; color:inherit; text-decoration:none"><img src="<?php echo e($toUrl($cfgLogo)); ?>" alt="<?php echo e($cfgName ?? 'Logo'); ?>" style="border-color: rgba(255,255,255,.2)"></a></div>
          <?php else: ?>
            <div class="footer-brand-text">
              <a href="<?php echo e(url('/')); ?>" style="color:inherit; text-decoration:none">
                <span class="footer-brand-name" style="color: <?php echo e($footerTextEffective); ?>"><?php echo e($cfgName ?? 'apx'); ?></span>
                <?php if(!empty($cfgTag)): ?><small class="footer-brand-tagline" style="color: <?php echo e($footerTextEffective); ?>"><?php echo e($cfgTag); ?></small><?php endif; ?>
              </a>
            </div>
          <?php endif; ?>
          <h4 style="color: <?php echo e($footerTextEffective); ?>"><?php echo e($aboutTitle); ?></h4>
          <?php if(!empty($aboutBody)): ?>
            <p style="color: <?php echo e($footerTextEffective); ?>"><?php echo e($aboutBody); ?></p>
          <?php else: ?>
            <p style="color: <?php echo e($footerTextEffective); ?>"><?php echo e($aboutText); ?></p>
          <?php endif; ?>
          <?php if(!empty($aboutLinkLabel) && !empty($aboutLinkUrl)): ?>
            <p style="margin-top:10px"><a href="<?php echo e($aboutLinkUrl); ?>" style="color: <?php echo e($footerLinkEffective); ?>"><?php echo e($aboutLinkLabel); ?> →</a></p>
          <?php endif; ?>
          <?php if($showSocial): ?>
            <div class="footer-social">
              <?php $__empty_1 = true; $__currentLoopData = $social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e($s->url); ?>" target="_blank" rel="noopener" title="<?php echo e($s->label); ?>" style="color: <?php echo e($footerLinkEffective); ?>"><?php echo e($s->icon ?? '🔗'); ?></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <?php endif; ?>
            </div>
          <?php endif; ?>
        </div>

        <div class="footer-col">
          <h4 style="color: <?php echo e($footerTextEffective); ?>"><?php echo e(__('site.services')); ?></h4>
          <ul style="color: <?php echo e($footerTextEffective); ?>">
            <?php if(isset($services) && $services->count()): ?>
              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#" style="color: <?php echo e($footerLinkEffective); ?>"><?php echo e($svc->title); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <li><a href="#" style="color: <?php echo e($footerLinkEffective); ?>">Air Freight</a></li>
              <li><a href="#" style="color: <?php echo e($footerLinkEffective); ?>">Ocean Freight</a></li>
            <?php endif; ?>
          </ul>
        </div>

        <div class="footer-col">
          <h4 style="color: <?php echo e($footerTextEffective); ?>"><?php echo e(__('site.quick_links')); ?></h4>
          <ul style="color: <?php echo e($footerTextEffective); ?>">
            <?php $__empty_1 = true; $__currentLoopData = $footerLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li><a href="<?php echo e($fl->url); ?>" style="color: <?php echo e($footerLinkEffective); ?>"><?php echo e($fl->label); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <li><a href="#" style="color: <?php echo e($footerLinkEffective); ?>">Privacy Policy</a></li>
              <li><a href="#" style="color: <?php echo e($footerLinkEffective); ?>">Terms of Service</a></li>
            <?php endif; ?>
          </ul>
        </div>

        <div class="footer-col">
          <h4 style="color: <?php echo e($footerTextEffective); ?>"><?php echo e(__('site.contact_us')); ?></h4>
          <ul style="color: <?php echo e($footerTextEffective); ?>">
            <?php if($contactAddr): ?><li>📍 <?php echo e($contactAddr); ?></li><?php endif; ?>
            <?php if($contactPhone): ?><li>📞 <?php echo e($contactPhone); ?></li><?php endif; ?>
            <?php if($contactEmail): ?><li>✉️ <?php echo e($contactEmail); ?></li><?php endif; ?>
            <?php if($footerHours): ?><li>🕑 <?php echo e($footerHours); ?></li><?php endif; ?>
          </ul>
        </div>
      </div>

      <div class="footer-bottom" style="color: <?php echo e($footerTextEffective); ?>">
        <span>© <span id="year"></span> <?php echo e($cfgName ?? 'Parcel Transport'); ?>. <?php echo e($aboutText); ?></span>
      </div>
    </div>
  </div>
</footer>

<?php /**PATH C:\wamp64\www\apx\resources\views/partials/footer.blade.php ENDPATH**/ ?>