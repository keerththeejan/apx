

<?php $__env->startSection('title', 'Parcel Tracking Links - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Parcel Tracking Links (3rd party)</h2>
    </div>
    <div>
      <a class="btn" href="<?php echo e(route('admin.trackinglinks.create')); ?>">Add tracking link</a>
    </div>
  </div>

  <p style="color:var(--muted); margin:0 0 12px">These links appear after Features on the home page. Use <code style="background:var(--accent); padding:2px 6px; border-radius:4px">{tracking_number}</code> in the URL so the tracking number is inserted when the user tracks.</p>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>URL template</th>
          <th>Order</th>
          <th>Visible</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($l->id); ?></td>
            <td><?php echo e($l->name); ?></td>
            <td><span style="color:#93c5fd; font-size:13px; word-break:break-all"><?php echo e(\Illuminate\Support\Str::limit($l->url_template, 60)); ?></span></td>
            <td><?php echo e($l->sort_order); ?></td>
            <td><?php echo e($l->is_visible ? 'Yes' : 'No'); ?></td>
            <td class="actions" style="display:flex; gap:8px">
              <a class="btn" href="<?php echo e(route('admin.trackinglinks.edit', $l)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.trackinglinks.destroy', $l)); ?>" onsubmit="return confirm('Delete this tracking link?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn" type="submit" style="background:var(--danger); border-color:var(--danger)">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" style="color:#94a3b8">No tracking links yet. Add one to show parcel tracking options after Features.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/trackinglinks/index.blade.php ENDPATH**/ ?>