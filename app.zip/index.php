<?php

// Forward all root requests to Laravel's public front controller.
require __DIR__ . '/public/index.php';
