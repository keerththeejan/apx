

<?php $__env->startSection('title', 'Change Password - Admin'); ?>
<?php $__env->startSection('brand', 'Change Password'); ?>

<?php $__env->startSection('content'); ?>
  <div class="wrap">
    <?php if($errors->any()): ?>
      <div class="error"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
      <div style="display:flex; gap:8px; align-items:center">
        <a class="btn" href="<?php echo e(route('admin.profile.edit')); ?>">Back</a>
        <h2 style="margin:0">Change password</h2>
      </div>
    </div>

    <form method="POST" action="<?php echo e(route('admin.profile.password.update')); ?>">
      <?php echo csrf_field(); ?>
      <label for="current_password">Current password</label>
      <input id="current_password" type="password" name="current_password" required autocomplete="current-password">
      <label for="password">New password</label>
      <input id="password" type="password" name="password" required autocomplete="new-password">
      <label for="password_confirmation">Confirm new password</label>
      <input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password">
      <div class="actions">
        <button class="btn" type="submit">Update password</button>
        <a class="btn" href="<?php echo e(route('admin.profile.edit')); ?>">Cancel</a>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/profile/password.blade.php ENDPATH**/ ?>