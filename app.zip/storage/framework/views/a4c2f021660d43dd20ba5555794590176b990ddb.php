

<?php $__env->startSection('title', 'Edit Daily Activity - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php
    $toUrl = function ($p) {
      if (empty($p)) return null;
      $p = trim((string) $p);
      if (\Illuminate\Support\Str::startsWith($p, ['http://','https://','data:'])) return $p;
      $path = ltrim($p, '/');
      if (\Illuminate\Support\Str::startsWith($path, 'uploads/')) {
        $path = 'public/'.$path;
      }
      return asset($path);
    };
  ?>
  <?php if($errors->any()): ?>
    <div class="error">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.activities.index')); ?>">Back</a>
      <h2 style="margin:0">Edit Daily Activity</h2>
    </div>
  </div>

  <form method="POST" action="<?php echo e(route('admin.activities.update', $item)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label>Title</label>
    <input type="text" name="title" value="<?php echo e(old('title', $item->title)); ?>" required>

    <label>Body</label>
    <textarea name="body" rows="5"><?php echo e(old('body', $item->body)); ?></textarea>

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px">
      <div>
        <label>Date</label>
        <input type="date" name="activity_date" value="<?php echo e(old('activity_date', $item->activity_date ? $item->activity_date->format('Y-m-d') : '')); ?>">
      </div>
      <div>
        <label>Order</label>
        <input type="number" min="0" name="sort_order" value="<?php echo e(old('sort_order', $item->sort_order)); ?>">
      </div>
    </div>

    <label>Image Upload</label>
    <input type="file" name="image_file" accept="image/*">

    <label>Image URL (optional)</label>
    <input type="text" name="image_url" value="<?php echo e(old('image_url', $item->image_url)); ?>" placeholder="/public/uploads/activities/example.jpg">

    <?php if(!empty($item->image_url)): ?>
      <div style="margin-top:10px">
        <img src="<?php echo e($toUrl($item->image_url)); ?>" alt="Current image" style="width:160px; height:100px; border-radius:12px; object-fit:cover; border:1px solid rgba(148,163,184,.25)">
      </div>
    <?php endif; ?>

    <label style="display:flex; align-items:center; gap:8px; margin-top:10px">
      <input type="checkbox" name="is_visible" value="1" <?php echo e(old('is_visible', $item->is_visible) ? 'checked' : ''); ?>> Visible
    </label>

    <div style="margin-top:14px">
      <button class="btn" type="submit">Save</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/activities/edit.blade.php ENDPATH**/ ?>