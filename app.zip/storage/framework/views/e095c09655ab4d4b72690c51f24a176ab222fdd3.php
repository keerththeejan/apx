

<?php $__env->startSection('title', 'Help Items - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Help Items</h2>
    </div>
    <div>
      <a class="btn" href="<?php echo e(route('admin.helpitems.create')); ?>">Add Item</a>
    </div>
  </div>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Icon</th>
          <th>Title</th>
          <th>Description</th>
          <th>Order</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($it->id); ?></td>
            <td><?php echo e($it->icon); ?></td>
            <td><?php echo e($it->title); ?></td>
            <td style="max-width:420px"><?php echo e(\Illuminate\Support\Str::limit($it->description, 120)); ?></td>
            <td><?php echo e($it->sort_order); ?></td>
            <td class="actions" style="display:flex; gap:8px">
              <a class="btn" href="<?php echo e(route('admin.helpitems.edit', $it)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.helpitems.destroy', $it)); ?>" onsubmit="return confirm('Delete this item?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn danger" type="submit">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" style="color:#94a3b8">No help items yet. Click "Add Item".</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/helpitems/index.blade.php ENDPATH**/ ?>