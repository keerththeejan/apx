

<?php $__env->startSection('title', 'Quotes - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Quotes</h2>
    </div>
  </div>

  <form method="get" style="display:flex; gap:8px; margin-bottom:10px">
    <select name="status" class="input" style="padding:8px 10px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">
      <option value="">All Status</option>
      <?php $__currentLoopData = ['new'=>'New','in_progress'=>'In Progress','closed'=>'Closed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>" <?php echo e(request('status')===$key? 'selected':''); ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="service_id" class="input" style="padding:8px 10px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">
      <option value="">All Services</option>
      <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($svc->id); ?>" <?php echo e((string)request('service_id')===(string)$svc->id? 'selected':''); ?>><?php echo e($svc->title); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn" type="submit">Filter</button>
  </form>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Email</th>
          <th>Service</th>
          <th>Subject</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($q->id); ?></td>
            <td><?php echo e($q->name); ?></td>
            <td><?php echo e($q->email); ?></td>
            <td><?php echo e(optional($q->service)->title ?? '—'); ?></td>
            <td><?php echo e($q->subject); ?></td>
            <td>
              <span style="padding:4px 8px; border-radius:8px; border:1px solid rgba(148,163,184,.25)"><?php echo e(ucfirst(str_replace('_',' ',$q->status))); ?></span>
            </td>
            <td class="actions" style="display:flex; gap:8px">
              <a class="btn" href="<?php echo e(route('admin.quotes.show', $q)); ?>">View</a>
              <a class="btn" href="<?php echo e(route('admin.quotes.edit', $q)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.quotes.destroy', $q)); ?>" onsubmit="return confirm('Delete this quote?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn danger" type="submit">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" style="color:#94a3b8">No quotes yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if(method_exists(($quotes ?? null),'links')): ?>
    <div style="margin-top:10px"><?php echo $quotes->withQueryString()->links(); ?></div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\APLX\resources\views/admin/quotes/index.blade.php ENDPATH**/ ?>