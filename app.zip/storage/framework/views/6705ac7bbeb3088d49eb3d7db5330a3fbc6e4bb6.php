

<?php $__env->startSection('title', 'Edit user - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="error"><?php echo e($errors->first()); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.users.index')); ?>">Back</a>
      <h2 style="margin:0">Edit user</h2>
    </div>
  </div>

  <form method="POST" action="<?php echo e(route('admin.users.update', $user)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label for="name">Name</label>
    <input id="name" type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required>

    <label for="email">Email (login)</label>
    <input id="email" type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required>

    <label for="password">New password (leave blank to keep current)</label>
    <input id="password" type="password" name="password" autocomplete="new-password">

    <label for="password_confirmation">Confirm new password</label>
    <input id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password">

    <label style="display:flex; gap:8px; align-items:center; margin-top:12px">
      <input type="checkbox" name="is_admin" value="1" <?php echo e(old('is_admin', $user->is_admin) ? 'checked' : ''); ?>> Admin (can access admin panel)
    </label>

    <div class="actions" style="margin-top:12px; display:flex; gap:8px">
      <button class="btn" type="submit">Update user</button>
      <a class="btn" href="<?php echo e(route('admin.users.index')); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>