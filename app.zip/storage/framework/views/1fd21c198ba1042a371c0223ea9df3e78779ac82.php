

<?php $__env->startSection('title', 'Create Quote'); ?>

<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="error"><?php echo e($errors->first()); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.quotes.index')); ?>">Back</a>
      <h2 style="margin:0">Create Quote</h2>
    </div>
  </div>

  <form method="POST" action="<?php echo e(route('admin.quotes.store')); ?>">
    <?php echo csrf_field(); ?>

    <label for="name">Name</label>
    <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)" required>

    <label for="email">Email</label>
    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)" required>

    <label for="phone">Phone</label>
    <input id="phone" type="text" name="phone" value="<?php echo e(old('phone')); ?>" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">

    <label for="subject">Subject</label>
    <input id="subject" type="text" name="subject" value="<?php echo e(old('subject')); ?>" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">

    <label for="service_id">Service</label>
    <select id="service_id" name="service_id" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">
      <option value="">—</option>
      <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($svc->id); ?>" <?php echo e((string)old('service_id')===(string)$svc->id? 'selected':''); ?>><?php echo e($svc->title); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="message">Message</label>
    <textarea id="message" name="message" class="input" style="min-height:120px; padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)" required><?php echo e(old('message')); ?></textarea>

    <label for="status">Status</label>
    <select id="status" name="status" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">
      <?php $__currentLoopData = ['new'=>'New','in_progress'=>'In Progress','closed'=>'Closed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>" <?php echo e(old('status','new')===$key? 'selected':''); ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="notes">Notes</label>
    <textarea id="notes" name="notes" class="input" style="min-height:120px; padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)"><?php echo e(old('notes')); ?></textarea>

    <div class="actions" style="margin-top:12px; display:flex; gap:8px">
      <button class="btn" type="submit">Create Quote</button>
      <a class="btn" href="<?php echo e(route('admin.quotes.index')); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/quotes/create.blade.php ENDPATH**/ ?>