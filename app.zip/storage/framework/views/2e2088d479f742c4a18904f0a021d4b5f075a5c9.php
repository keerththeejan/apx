

<?php $__env->startSection('title', 'Edit Quote'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.quotes.index')); ?>">Back</a>
      <h2 style="margin:0">Edit Quote #<?php echo e($quote->id); ?></h2>
    </div>
  </div>

  <form method="POST" action="<?php echo e(route('admin.quotes.update', $quote)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label for="service_id">Service</label>
    <select id="service_id" name="service_id" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">
      <option value="">—</option>
      <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($svc->id); ?>" <?php echo e((string)old('service_id', $quote->service_id)===(string)$svc->id? 'selected':''); ?>><?php echo e($svc->title); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="status">Status</label>
    <select id="status" name="status" class="input" style="padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)">
      <?php $__currentLoopData = ['new'=>'New','in_progress'=>'In Progress','closed'=>'Closed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>" <?php echo e(old('status', $quote->status)===$key? 'selected':''); ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="notes">Notes</label>
    <textarea id="notes" name="notes" class="input" style="min-height:120px; padding:10px 12px; border-radius:8px; background:#0b1a21; color:#e5e7eb; border:1px solid rgba(148,163,184,.25)"><?php echo e(old('notes', $quote->notes)); ?></textarea>

    <div class="actions" style="margin-top:12px; display:flex; gap:8px">
      <button class="btn" type="submit">Save</button>
      <a class="btn" href="<?php echo e(route('admin.quotes.show', $quote)); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\APLX\resources\views/admin/quotes/edit.blade.php ENDPATH**/ ?>