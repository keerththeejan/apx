

<?php $__env->startSection('title', 'Edit Home Banner'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>
  <?php if($errors->any()): ?>
    <div class="error"><?php echo e($errors->first()); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Edit Home Banner</h2>
    </div>
  </div>

  <form method="POST" action="<?php echo e(route('admin.banner.update')); ?>">
    <?php echo csrf_field(); ?>

    <label for="eyebrow">Eyebrow</label>
    <input id="eyebrow" type="text" name="eyebrow" value="<?php echo e(old('eyebrow', optional($banner)->eyebrow)); ?>" placeholder="SAFE TRANSPORTATION & LOGISTICS">

    <label for="title_line1">Title Line 1</label>
    <input id="title_line1" type="text" name="title_line1" value="<?php echo e(old('title_line1', optional($banner)->title_line1)); ?>" placeholder="Adaptable coordinated factors">

    <label for="title_line2">Title Line 2</label>
    <input id="title_line2" type="text" name="title_line2" value="<?php echo e(old('title_line2', optional($banner)->title_line2)); ?>" placeholder="Quick Conveyance">

    <label for="subtitle">Subtitle</label>
    <textarea id="subtitle" name="subtitle" placeholder="Short description for the banner"><?php echo e(old('subtitle', optional($banner)->subtitle)); ?></textarea>

    <label for="bg_image_url">Background Image URL</label>
    <input id="bg_image_url" type="text" name="bg_image_url" value="<?php echo e(old('bg_image_url', optional($banner)->bg_image_url)); ?>" placeholder="https://...">
    <small class="help">Paste a full image URL. We can switch to file uploads later if you prefer.</small>

    <div class="row">
      <div>
        <label for="primary_text">Primary Button Text</label>
        <input id="primary_text" type="text" name="primary_text" value="<?php echo e(old('primary_text', optional($banner)->primary_text)); ?>" placeholder="Get Started">
      </div>
      <div>
        <label for="primary_url">Primary Button URL</label>
        <input id="primary_url" type="text" name="primary_url" value="<?php echo e(old('primary_url', optional($banner)->primary_url)); ?>" placeholder="#get-started">
      </div>
    </div>

    <div class="row">
      <div>
        <label for="secondary_text">Secondary Button Text</label>
        <input id="secondary_text" type="text" name="secondary_text" value="<?php echo e(old('secondary_text', optional($banner)->secondary_text)); ?>" placeholder="Learn More">
      </div>
      <div>
        <label for="secondary_url">Secondary Button URL</label>
        <input id="secondary_url" type="text" name="secondary_url" value="<?php echo e(old('secondary_url', optional($banner)->secondary_url)); ?>" placeholder="#learn">
      </div>
    </div>

    <div class="actions">
      <button class="btn" type="submit">Save Banner</button>
      <a class="btn" href="/" target="_blank">View Site</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\APLX\resources\views/admin/banner/edit.blade.php ENDPATH**/ ?>