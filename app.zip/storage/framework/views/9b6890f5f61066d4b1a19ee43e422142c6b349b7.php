<?php
  $seoTitle = $seoTitle ?? config('app.name', 'Parcel Transport');
  $seoDescription = $seoDescription ?? null;
  $seoKeywords = $seoKeywords ?? null;
  $seoCanonical = $seoCanonical ?? url()->current();
  $seoImage = $seoImage ?? null;
  $seoSiteName = $seoSiteName ?? $seoTitle;
  $noindex = $noindex ?? false;
  $seoImageAbsolute = $seoImage ? (str_starts_with($seoImage, 'http') ? $seoImage : url($seoImage)) : null;
?>
<title><?php echo e($seoTitle); ?></title>
<?php if($seoDescription): ?>
<meta name="description" content="<?php echo e(\Illuminate\Support\Str::limit(strip_tags($seoDescription), 160)); ?>">
<?php endif; ?>
<?php if($seoKeywords): ?>
<meta name="keywords" content="<?php echo e(is_array($seoKeywords) ? implode(', ', $seoKeywords) : $seoKeywords); ?>">
<?php endif; ?>
<?php if($noindex): ?>
<meta name="robots" content="noindex, nofollow">
<?php else: ?>
<link rel="canonical" href="<?php echo e($seoCanonical); ?>">
<?php endif; ?>

<meta property="og:type" content="website">
<meta property="og:title" content="<?php echo e($seoTitle); ?>">
<?php if($seoDescription): ?>
<meta property="og:description" content="<?php echo e(\Illuminate\Support\Str::limit(strip_tags($seoDescription), 200)); ?>">
<?php endif; ?>
<meta property="og:url" content="<?php echo e($seoCanonical); ?>">
<meta property="og:site_name" content="<?php echo e($seoSiteName); ?>">
<?php if($seoImageAbsolute): ?>
<meta property="og:image" content="<?php echo e($seoImageAbsolute); ?>">
<?php endif; ?>
<meta property="og:locale" content="<?php echo e(str_replace('-', '_', app()->getLocale())); ?>">

<meta name="twitter:card" content="<?php echo e($seoImageAbsolute ? 'summary_large_image' : 'summary'); ?>">
<meta name="twitter:title" content="<?php echo e($seoTitle); ?>">
<?php if($seoDescription): ?>
<meta name="twitter:description" content="<?php echo e(\Illuminate\Support\Str::limit(strip_tags($seoDescription), 200)); ?>">
<?php endif; ?>
<?php if($seoImageAbsolute): ?>
<meta name="twitter:image" content="<?php echo e($seoImageAbsolute); ?>">
<?php endif; ?>
<?php if(!empty($jsonLd)): ?>
<script type="application/ld+json"><?php echo json_encode($jsonLd, 15, 512) ?></script>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\apx\resources\views/partials/seo-meta.blade.php ENDPATH**/ ?>