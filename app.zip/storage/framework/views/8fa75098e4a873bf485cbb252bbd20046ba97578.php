

<?php $__env->startSection('title', 'Gallery - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Gallery</h2>
    </div>
    <div>
      <a class="btn" href="<?php echo e(route('admin.gallery.create')); ?>">Add Item</a>
    </div>
  </div>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Image</th>
          <th>Label</th>
          <th>Date</th>
          <th>Order</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($it->id); ?></td>
            <td><img class="thumb" src="<?php echo e($it->image_url); ?>" alt="<?php echo e($it->label); ?>" style="width:120px; height:70px; object-fit:cover; border-radius:8px; border:1px solid rgba(148,163,184,.12)"></td>
            <td><?php echo e($it->label); ?></td>
            <td><?php echo e($it->date_label); ?></td>
            <td><?php echo e($it->sort_order); ?></td>
            <td class="actions" style="display:flex; gap:8px">
              <a class="btn" href="<?php echo e(route('admin.gallery.edit', $it)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.gallery.destroy', $it)); ?>" onsubmit="return confirm('Delete this item?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn danger" type="submit">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" style="color:#94a3b8">No gallery items yet. Click "Add Item".</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\APLX\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>