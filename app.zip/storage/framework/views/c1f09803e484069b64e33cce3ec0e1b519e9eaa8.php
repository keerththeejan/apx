

<?php $__env->startSection('title', 'Quotation Countries - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Quotation Countries</h2>
    </div>
    <div>
      <a class="btn" href="<?php echo e(route('admin.quotationcountries.create')); ?>">Add Country</a>
    </div>
  </div>

  <p style="color:var(--muted); margin:0 0 12px">Countries used for price quotation. Total = base fee + (weight kg × rate per kg).</p>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Code</th>
          <th>Rate/kg</th>
          <th>Base fee</th>
          <th>Order</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($c->id); ?></td>
            <td><?php echo e($c->name); ?></td>
            <td><?php echo e($c->code ?? '—'); ?></td>
            <td><?php echo e(number_format($c->rate_per_kg, 2)); ?></td>
            <td><?php echo e(number_format($c->base_fee ?? 0, 2)); ?></td>
            <td><?php echo e($c->sort_order); ?></td>
            <td style="display:flex; gap:8px">
              <a class="btn" href="<?php echo e(route('admin.quotationcountries.edit', $c)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.quotationcountries.destroy', $c)); ?>" onsubmit="return confirm('Remove this country?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn" type="submit" style="background:var(--danger); border-color:var(--danger)">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" style="color:#94a3b8">No countries yet. Add countries so customers can get a price quote by weight.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/quotationcountries/index.blade.php ENDPATH**/ ?>