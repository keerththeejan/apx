

<?php $__env->startSection('title', 'Add tracking link - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="error"><?php echo e($errors->first()); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.trackinglinks.index')); ?>">Back</a>
      <h2 style="margin:0">Add tracking link (3rd party)</h2>
    </div>
  </div>

  <form method="POST" action="<?php echo e(route('admin.trackinglinks.store')); ?>">
    <?php echo csrf_field(); ?>

    <label for="name">Name (e.g. DHL, FedEx, UPS)</label>
    <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required placeholder="DHL">

    <label for="url_template">URL template</label>
    <input id="url_template" type="text" name="url_template" value="<?php echo e(old('url_template')); ?>" required placeholder="https://www.dhl.com/track?AWB={tracking_number}">
    <div style="color:var(--muted); font-size:12px; margin-top:4px">Use <code>{tracking_number}</code> where the tracking number should go. Opens in new tab.</div>

    <label for="sort_order">Sort order</label>
    <input id="sort_order" type="number" min="0" name="sort_order" value="<?php echo e(old('sort_order', 0)); ?>">

    <label style="display:flex; gap:8px; align-items:center; margin-top:12px">
      <input type="checkbox" name="is_visible" value="1" <?php echo e(old('is_visible', true) ? 'checked' : ''); ?>> Visible on home page
    </label>

    <div class="actions" style="margin-top:12px; display:flex; gap:8px">
      <button class="btn" type="submit">Create</button>
      <a class="btn" href="<?php echo e(route('admin.trackinglinks.index')); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/trackinglinks/create.blade.php ENDPATH**/ ?>