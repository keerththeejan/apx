

<?php $__env->startSection('title', 'Features - Admin'); ?>

<?php $__env->startSection('brand', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Features</h2>
    </div>
    <div>
      <a class="btn" href="<?php echo e(route('admin.features.create')); ?>">Add Feature</a>
    </div>
  </div>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Icon</th>
          <th>Title</th>
          <th>Description</th>
          <th>Order</th>
          <th>Visible</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($f->id); ?></td>
            <td>
              <?php if(!empty($f->icon_image_url)): ?>
                <img src="<?php echo e($f->icon_image_url); ?>" alt="Icon" style="width:28px; height:28px; border-radius:6px; object-fit:cover; border:1px solid rgba(148,163,184,.25)">
              <?php else: ?>
                <?php echo e($f->icon ?? '•'); ?>

              <?php endif; ?>
            </td>
            <td><?php echo e($f->title); ?></td>
            <td style="max-width:520px"><?php echo e(\Illuminate\Support\Str::limit($f->description, 160)); ?></td>
            <td><?php echo e($f->sort_order); ?></td>
            <td>
              <?php if($f->is_visible): ?>
                <span style="background:#052; color:#c7f9cc; border:1px solid #0a4; padding:4px 8px; border-radius:8px">Visible</span>
              <?php else: ?>
                <span style="background: rgba(239,68,68,.15); color:#fecaca; border:1px solid rgba(239,68,68,.35); padding:4px 8px; border-radius:8px">Hidden</span>
              <?php endif; ?>
            </td>
            <td class="actions">
              <form method="POST" action="<?php echo e(route('admin.features.toggle', $f)); ?>" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <button class="btn" type="submit" style="margin-right:6px"><?php echo e($f->is_visible ? 'Hide' : 'Show'); ?></button>
              </form>
              <a class="btn" href="<?php echo e(route('admin.features.edit', $f)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.features.destroy', $f)); ?>" onsubmit="return confirm('Delete this feature?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn danger" type="submit">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" style="color:#94a3b8">No features yet. Click "Add Feature".</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div style="margin-top:10px">
    <?php echo $features->links(); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\APLX\resources\views/admin/features/index.blade.php ENDPATH**/ ?>