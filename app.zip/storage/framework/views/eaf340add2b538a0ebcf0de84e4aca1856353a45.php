

<?php $__env->startSection('title', 'Nav Links - Admin'); ?>
<?php $__env->startSection('brand', 'Nav Links'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Nav Links</h2>
    </div>
    <div>
      <a class="btn" href="<?php echo e(route('admin.navlinks.create')); ?>">Add Link</a>
    </div>
  </div>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Label</th>
          <th>URL</th>
          <th>Target</th>
          <th>Visible</th>
          <th>Order</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($l->id); ?></td>
            <td><?php echo e($l->label); ?></td>
            <td style="max-width:420px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap"><?php echo e($l->url); ?></td>
            <td><?php echo e($l->target ?? '_self'); ?></td>
            <td><?php echo e($l->is_visible ? 'Yes' : 'No'); ?></td>
            <td><?php echo e($l->sort_order); ?></td>
            <td class="actions" style="display:flex; gap:8px">
              <a class="btn" href="<?php echo e(route('admin.navlinks.edit', $l)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.navlinks.destroy', $l)); ?>" onsubmit="return confirm('Delete this link?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn logout" type="submit" style="padding:8px 12px; font-size:14px">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" style="color:var(--muted)">No links yet. Click "Add Link".</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/navlinks/index.blade.php ENDPATH**/ ?>