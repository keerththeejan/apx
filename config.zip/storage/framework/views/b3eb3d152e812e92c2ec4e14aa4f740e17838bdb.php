

<?php $__env->startSection('title', 'Quotation Rates - Admin'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session('status')): ?>
    <div class="status"><?php echo e(session('status')); ?></div>
  <?php endif; ?>

  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px">
    <div style="display:flex; gap:8px; align-items:center">
      <a class="btn" href="<?php echo e(route('admin.dashboard')); ?>">Back</a>
      <h2 style="margin:0">Quotation Rates</h2>
    </div>
    <div>
      <a class="btn" href="<?php echo e(route('admin.quotationrates.create')); ?>">Add Rate</a>
    </div>
  </div>

  <p style="color:var(--muted); margin:0 0 12px">Country + Service (e.g. DHL, FedEx, UPS) with Customer price and Dealer price per unit. Total = unit price × qty.</p>

  <div class="tablewrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Country</th>
          <th>Service</th>
          <th>Customer price</th>
          <th>Dealer price</th>
          <th>Order</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($r->id); ?></td>
            <td><?php echo e($r->country); ?></td>
            <td><?php echo e($r->service); ?></td>
            <td><?php echo e(number_format($r->customer_price, 2)); ?></td>
            <td><?php echo e(number_format($r->dealer_price, 2)); ?></td>
            <td><?php echo e($r->sort_order); ?></td>
            <td style="display:flex; gap:8px">
              <a class="btn" href="<?php echo e(route('admin.quotationrates.edit', $r)); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.quotationrates.destroy', $r)); ?>" onsubmit="return confirm('Remove this rate?')" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn" type="submit" style="background:var(--danger); border-color:var(--danger)">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" style="color:#94a3b8">No rates yet. Add Country, Service, Customer price and Dealer price.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\apx\resources\views/admin/quotationrates/index.blade.php ENDPATH**/ ?>